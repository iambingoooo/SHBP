﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using STP.Account;

namespace TestProject_Register
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Register r = new Register();

        }
    }
}
