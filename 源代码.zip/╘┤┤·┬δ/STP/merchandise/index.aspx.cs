﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using STP.Models;

namespace STP.Account
{
    public partial class ManageProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {
                DB db = new DB();
                string sql = "select id from users where name='" + Session["user"] + "'";
                string id = "";
                SqlDataReader dr = db.ExceRead(sql);
                if (dr.Read())
                {
                    id = dr["id"].ToString().Trim();
                }
                dr.Close();
                sql = "exec selectProductByUser '" + id + "'";
                dr = db.ExceRead(sql);
                while (dr.Read())
                {
                    TableRow row = new TableRow();
                    TableCell cellHead = new TableCell();
                    TableCell cellContent = new TableCell();
                    HyperLink img = new HyperLink();
                    img.ImageUrl = dr["path"].ToString().Trim();
                    img.ImageHeight = 200;
                    img.ImageWidth = 200;
                    HyperLink link = new HyperLink();
                    link.Text = dr["name"].ToString().Trim();
                    link.NavigateUrl = "~/merchandise/detail?id=" + dr["id"];
                    cellHead.Controls.Add(img);
                    cellContent.Controls.Add(link);
                    row.Cells.Add(cellHead);
                    row.Cells.Add(cellContent);
                    products.Rows.Add(row);
                }
            }
            else
            {
                Session["returnUrl"] = Request.Url.ToString();
                Response.Redirect("~/user/Login");
            }
        }

        protected void submit_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/merchandise/new");
        }
    }
}