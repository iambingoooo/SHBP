﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using STP.Models;

namespace STP.Product
{
    public partial class ProductInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["id"] == null || Request.QueryString["id"].Length < 1)
            {
                Response.Redirect("~/index.aspx");
                return;
            }
            DB db = new DB();
            //商品id
            string pid = Request.QueryString["id"].ToString().Trim();
            //商品所有者id
            string userid = "";
            //获取和展示商品信息
            string sql = "exec selectProductById '" + pid + "'";
            SqlDataReader dr = db.ExceRead(sql);
            if (dr.Read())
            {
                userid = dr["uid"].ToString().Trim();
                Name.Text = dr["name"].ToString().Trim();
                if(dr["state"].ToString()=="0")
                {
                    state.Text = "未出售";
                }
                else
                {
                    state.Text = "已出售";
                }
                Price.Text = dr["price"].ToString().Trim() + " 元";
                Quote.Text = dr["maxprice"].ToString().Trim() + " 元";
                Image.ImageUrl = dr["path"].ToString().Trim();
                Content.Text = dr["content"].ToString().Trim();
                Time.Text = dr["time"].ToString().Trim();
                dr.Close();
                string tags = "";
                dr = db.ExceRead("exec selectTagsByProductId '" + pid + "'");
                if(dr.Read())
                {
                    tags += dr["name"] + ",";
                }
                if(tags.Length>0)tags = tags.Substring(0, tags.Length - 1);
                Tags.Text = tags;
                dr.Close();
                dr = db.ExceRead("select nickname from users where id='" + userid + "'");
                if(dr.Read())
                {
                    Username.Text = dr["nickname"].ToString().Trim();
                    Username.NavigateUrl = "~/user/Userinfo?id=" + userid;
                }
                dr.Close();
                //隐藏删除该商品按钮
                deleteProduct.Visible = false;
                completeTransaction.Visible = false;
                //设置出价和收藏的相关内容
                deletequote.Visible = false;
                addCollection.Visible = false;
                deleteCollection.Visible = false;
                edit.Visible = false;
                if(Session["user"]!=null)
                {
                    //获取用户id
                    string uid = "";
                    dr = db.ExceRead("select id from users where name='" + Session["user"].ToString().Trim() + "'");
                    if (dr.Read()) uid = dr["id"].ToString().Trim();
                    dr.Close();
                    //如果是本人，则不显示出价和收藏相关
                    if (uid == userid)
                    {
                        NewQuote.Visible = false;
                        submit.Visible = false;
                        deleteProduct.Visible = true;
                        completeTransaction.Visible = true;
                        edit.Visible = true;

                        Myquote.Text = "--";
                        return;
                    }
                    //获取用户的出价信息
                    dr = db.ExceRead("select price from quotes where uid='" + uid + "' and pid='" + pid + "'");
                    if(dr.Read())
                    {
                        Myquote.Text = dr["price"].ToString().Trim();
                        deletequote.Visible = true;
                        completeTransaction.Visible = true;
                        completeTransaction.Visible = false;
                    }
                    else
                    {
                        Myquote.Text = "您未出价";
                        
                    }
                    dr.Close();
                    //获取用户是否收藏
                    dr = db.ExceRead("select * from collections where uid='" + uid + "' and pid='" + pid + "'");
                    if(dr.Read())
                    {
                        deleteCollection.Visible = true;
                    }
                    else
                    {
                        addCollection.Visible = true;
                    }
                    dr.Close();
                    //如果是管理员，删除各种按键，显示可以一键删除商品的权限按钮
                    if(Session["user"].ToString().Trim()=="siteAdmin")
                    {
                        deletequote.Visible = false;
                        addCollection.Visible = false;
                        deleteCollection.Visible = false;
                        NewQuote.Visible = false;
                        Myquote.Text = "--";
                        submit.Visible = false;
                        completeTransaction.Visible = false;
                        deleteProduct.Visible = true;
                    }
                }
                else
                {
                    Myquote.Text = "请登录查看";
                }
            }
            else
            {
                Response.Redirect("~/index.aspx");
            }
        }

        protected void submit_Click(object sender, EventArgs e)
        {
            if(Session["user"]==null)
            {
                Session["returnUrl"] = Request.Url.ToString();
                Response.Redirect("~/user/Login");
            }
            string quote = NewQuote.Text;
            float quotenum;
            if(float.TryParse(quote, out quotenum))
            {
                DB db = new DB();
                string uid = "";
                SqlDataReader dr = db.ExceRead("select id from users where name='" + Session["user"].ToString().Trim() + "'");
                if(dr.Read())
                {
                    uid = dr["id"].ToString().Trim();
                }
                dr.Close();
                db.ExceSql("exec insertQuote '" + uid + "','" + Request.QueryString["id"] + "','" + quotenum + "'");
                DB db2 = new DB();
                SqlDataReader dr2 = db.ExceRead("select uid from products where id='" + Request.QueryString["id"].ToString().Trim() + "'");
                if(dr2.Read())
                {
                    uid = dr2["uid"].ToString().Trim();
                }
                dr.Close();
                Response.Redirect("~/Account/AddLetter?id="+uid);
            }
            Response.Redirect("~/");
        }

        protected void deletequote_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            //商品id
            string pid = Request.QueryString["id"].ToString().Trim();
            //用户id
            string uid = "";
            SqlDataReader dr = db.ExceRead("select id from users where name='" + Session["user"].ToString().Trim() + "'");
            if (dr.Read()) uid = dr["id"].ToString().Trim();
            dr.Close();
            //删除用户对商品的报价
            db.ExceSql("delete from quotes where uid='" + uid + "' and pid='" + pid + "'");
            Response.Redirect(Request.Url.ToString().Trim());
        }

        protected void addCollection_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            //商品id
            string pid = Request.QueryString["id"].ToString().Trim();
            //用户id
            string uid = "";
            SqlDataReader dr = db.ExceRead("select id from users where name='" + Session["user"].ToString().Trim() + "'");
            if (dr.Read()) uid = dr["id"].ToString().Trim();
            dr.Close();
            //增加收藏
            db.ExceSql("exec insertCollection '" + uid + "','" + pid + "'");
            Response.Redirect(Request.Url.ToString().Trim());
        }

        protected void deleteCollection_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            //商品id
            string pid = Request.QueryString["id"].ToString().Trim();
            //用户id
            string uid = "";
            SqlDataReader dr = db.ExceRead("select id from users where name='" + Session["user"].ToString().Trim() + "'");
            if (dr.Read()) uid = dr["id"].ToString().Trim();
            dr.Close();
            //取消收藏
            db.ExceSql("delete from collections where uid='" + uid + "' and pid='" + pid + "'");
            Response.Redirect(Request.Url.ToString().Trim());
        }

        protected void deleteProduct_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            //商品id
            string pid = Request.QueryString["id"].ToString().Trim();
            //删除商品
            db.ExceSql("delete from products where id='" + pid + "'");
            db.ExceSql("delete from products_tags where pid='" + pid + "'");
            db.ExceSql("delete from products_images where pid='" + pid + "'");
            Response.Redirect("~/merchandise/index");
        }

        protected void completeTransaction_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            //商品id
            string pid = Request.QueryString["id"].ToString().Trim();
            //update product state
            db.ExceSql("update products set state=1 where id=" + pid);
            Response.Redirect("~/SearchResult");
        }

        protected void complaint_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Account/AddLetter?id=1");
        }

        protected void edit_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/merchandise/edit.aspx?id="+Request.QueryString["id"]);
        }
    }
}