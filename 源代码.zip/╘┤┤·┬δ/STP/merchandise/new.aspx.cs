﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using STP.Models;

namespace STP.Account
{
    public partial class AddProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {
                DB db = new DB();
            }
            else
            {
                Response.Redirect("~/index.aspx");
            }
        }

        protected void submit_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            Boolean fileOk = false;
            string name = Name.Text;
            string price = Price.Text;
            string content = Content.Text;
            string uid = "";
            if (name.Length < 1 || price.Length < 1 || content.Length < 1)
            {
                return;
            }
            //确定用户id
            string sql = "select id from users where name='" + Session["user"] + "'";
            SqlDataReader dr = db.ExceRead(sql);
            if (dr.Read())
            {
                uid = dr["id"].ToString().Trim();
            }
            dr.Close();
            //找出id
            string id = "";
            sql = "select isnull(max(cast(id as int)),0)+1 from products";
            dr = db.ExceRead(sql);
            if (dr.Read())
            {
                id = dr[0].ToString().Trim();
            }
            dr.Close();
            //上传图片
            string mappath = "";
            string virpath = "";
            if (picUpload.HasFile)//验证是否包含文件
            {
                //取得文件的扩展名,并转换成小写
                string fileExtension = Path.GetExtension(picUpload.FileName).ToLower();
                //验证上传文件是否图片格式
                fileOk = IsImage(fileExtension);
                if (fileOk)
                {
                    //对上传文件的大小进行检测，限定文件最大不超过8M
                    if (picUpload.PostedFile.ContentLength < 8192000)
                    {
                        string filepath = "/img/";
                        if (Directory.Exists(Server.MapPath(filepath)) == false)//如果不存在就创建file文件夹
                        {
                            Directory.CreateDirectory(Server.MapPath(filepath));
                        }
                        virpath = filepath + "productimg_"+ id + fileExtension;//这是存到服务器上的虚拟路径
                        mappath = Server.MapPath(virpath);//转换成服务器上的物理路径
                        picUpload.PostedFile.SaveAs(mappath);//保存图片
                    }
                }
            }
            if (virpath == "") virpath = "/img/default2.jpg";
            //插入信息
            sql = "exec insertProduct '" + name + "','" + uid + "','" + price + "','" + content + "','" + virpath + "'";
            db.ExceSql(sql);
            //设置标签
            string tags = Tags.Text;
            string[] taglist = tags.Split(',');
            foreach (string tag in taglist)
            {
                if (tag.Length > 0)
                {
                    db.ExceSql("exec insertTagForProduct '" + id + "','" + tag + "'");
                }
            }
            Response.Redirect("~/merchandise/detail?id="+id);
        }

        public bool IsImage(string str)
        {
            bool isimage = false;
            string thestr = str.ToLower();
            //限定只能上传jpg和gif图片
            string[] allowExtension = { ".jpg", ".gif", ".bmp", ".png" };
            //对上传的文件的类型进行一个个匹对
            for (int i = 0; i < allowExtension.Length; i++)
            {
                if (thestr == allowExtension[i])
                {
                    isimage = true;
                    break;
                }
            }
            return isimage;
        }
    }
}