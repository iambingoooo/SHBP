﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;

namespace STP.Models
{
    public class DB
    {
        protected SqlConnection conn;
        protected string constr;
        public DB()
        {
            constr = @"Data Source=JESSIEJ0122\SQLEXPRESS;Initial Catalog=stpdb;Integrated Security=True";
        }
        public void Open()
        {
            if (conn == null)
            {
                conn = new SqlConnection(constr);
                conn.Open();
            }
            else
            {
                if (conn.State.Equals(ConnectionState.Closed))
                    conn.Open();
            }
        }
        public void Close()
        {
            if (conn.State.Equals(ConnectionState.Open))
            {
                conn.Close();
            }
        }
        public bool ExceSql(string strsqlcom)
        {
            Debug.Print("sql:" + strsqlcom);
            Open();
            SqlCommand sqlcom = new SqlCommand(strsqlcom, conn);
            try
            {
                sqlcom.ExecuteNonQuery();
                return true;
            }
            catch(Exception e)
            {
                Debug.Print(e.Message);
                return false;
            }
            finally
            {
                Close();
            }
        }
        public SqlDataReader ExceRead(string strsqlcom)
        {
            Debug.Print("sql:" + strsqlcom);
            Open();
            SqlCommand sqlcom = new SqlCommand(strsqlcom, conn);
            SqlDataReader read;
            try
            {
                read = sqlcom.ExecuteReader();
                return read;
            }
            catch(Exception e)
            {
                Debug.Print(e.Message);
                return null;
            }
        }
    }
}