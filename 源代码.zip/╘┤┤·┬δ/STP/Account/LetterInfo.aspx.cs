﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using STP.Models;

namespace STP.Account
{
    public partial class LetterInfo : System.Web.UI.Page
    {
        private string fuid = "";
        private string tuid = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {
                if (Request.QueryString["id"] == null)
                {
                    Response.Redirect("~/");
                }
                //信的id
                string lid = Request.QueryString["id"].ToString().Trim();
                DB db = new DB();
                //获取和展示信的信息
                string sql = "select * from letters where id='" + lid + "'";
                SqlDataReader dr = db.ExceRead(sql);
                if(dr.Read())
                {
                    fuid = dr["fuid"].ToString().Trim();
                    tuid = dr["tuid"].ToString().Trim();
                    Ltitle.Text = dr["ltitle"].ToString().Trim();
                    Lcontent.Text = dr["lcontent"].ToString().Trim();
                    Ltime.Text = dr["time"].ToString().Trim();
                }
                dr.Close();
                //用户id
                string id = "";
                dr = db.ExceRead("select id from users where name='" + Session["user"] + "'");
                if (dr.Read()) id = dr["id"].ToString().Trim();
                dr.Close();
                //若用户并非此信息交互一方，则跳出
                if (fuid != id && tuid != id) Response.Redirect("~/");
                Reply.Visible = false;
                //若为收信人，设置已读并显示回信按钮
                if (tuid == id)
                {
                    db.ExceSql("update letters set ischecked='1' where id='" + lid + "'");
                    Reply.Visible = true;
                }  
                //展示双方姓名
                dr = db.ExceRead("select nickname from users where id='" + fuid + "'");
                if (dr.Read()) Lfusername.Text = dr["nickname"].ToString().Trim();
                dr.Close();
                dr = db.ExceRead("select nickname from users where id='" + tuid + "'");
                if (dr.Read()) Ltusername.Text = dr["nickname"].ToString().Trim();
                dr.Close();
            }
            else
            {
                Session["returnUrl"] = Request.Url.ToString();
                Response.Redirect("~/user/Login");
            }
        }

        protected void Unnamed6_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            //信的id
            string lid = Request.QueryString["id"].ToString().Trim();
            //删除信
            db.ExceSql("delete from letters where id='" + lid + "'");
            if(Session["returnUrl"]==null)
            {
                Response.Redirect("~/Account/ManageInbox");
            }
            else
            {
                string url = Session["returnUrl"].ToString().Trim();
                Session["returnUrl"] = null;
                Response.Redirect(url);
            }
        }

        protected void Unnamed6_Click1(object sender, EventArgs e)
        {
            Response.Redirect("~/Account/AddLetter?id=" + fuid);
        }
    }
}