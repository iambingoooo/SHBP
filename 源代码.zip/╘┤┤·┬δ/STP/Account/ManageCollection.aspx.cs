﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using STP.Models;

namespace STP.Account
{
    public partial class ManageCollection : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {
                DB db = new DB();
                DB db2 = new DB();
                //用户id
                string sql = "select id from users where name='" + Session["user"] + "'";
                string uid = "";
                SqlDataReader dr = db.ExceRead(sql);
                SqlDataReader dr2;
                if (dr.Read())
                {
                    uid = dr["id"].ToString().Trim();
                }
                dr.Close();
                //获取收藏商品的id
                sql = "select pid from collections where uid='" + uid + "'";
                dr = db.ExceRead(sql);
                while (dr.Read())
                {
                    //根据商品id获取信息
                    string pid = dr["pid"].ToString().Trim();
                    dr2 = db2.ExceRead("exec selectProductById '" + pid + "'");
                    if(dr2.Read())
                    {
                        TableRow row = new TableRow();
                        TableCell cellHead = new TableCell();
                        TableCell cellContent = new TableCell();
                        HyperLink img = new HyperLink();
                        img.ImageUrl = dr2["path"].ToString().Trim();
                        img.ImageHeight = 200;
                        img.ImageWidth = 200;
                        HyperLink link = new HyperLink();
                        link.Text = dr2["name"].ToString().Trim();
                        link.NavigateUrl = "~/merchandise/detail?id=" + dr2["id"];
                        cellHead.Controls.Add(img);
                        cellContent.Controls.Add(link);
                        row.Cells.Add(cellHead);
                        row.Cells.Add(cellContent);
                        Collections.Rows.Add(row);
                    }
                    dr2.Close();
                }
                dr.Close();
            }
            else
            {
                Session["returnUrl"] = Request.Url.ToString();
                Response.Redirect("~/user/Login");
            }
        }
    }
}