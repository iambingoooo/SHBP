﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using STP.Models;

namespace STP.Account
{
    public partial class ManageFriend : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {
                Session["returnUrl"] = Request.Url;
                DB db = new DB();
                //获取用户id
                string sql = "select id from users where name='" + Session["user"] + "'";
                string id = "";
                SqlDataReader dr = db.ExceRead(sql);
                if (dr.Read()) id = dr["id"].ToString().Trim();
                dr.Close();
                //获取好友列表
                sql = "select users.nickname,users.id from users,friends where friends.buid='" + id + "' and friends.tuid=users.id";
                dr = db.ExceRead(sql);
                TableRow trow = new TableRow();
                TableCell tcell1 = new TableCell();
                Label t1 = new Label();
                t1.Text = "昵称";
                t1.Font.Bold = true;
                tcell1.Controls.Add(t1);
                trow.Cells.Add(tcell1);
                Friends.Rows.Add(trow);
                while (dr.Read())
                {
                    TableRow row = new TableRow();
                    TableCell cell1 = new TableCell();
                    HyperLink title = new HyperLink();
                    title.Text = dr["nickname"].ToString().Trim();
                    title.NavigateUrl = "~/user/UserInfo?id=" + dr["id"].ToString().Trim();
                    cell1.Controls.Add(title);
                    row.Cells.Add(cell1);
                    Friends.Rows.Add(row);
                }
            }
            else
            {
                Session["returnUrl"] = Request.Url.ToString();
                Response.Redirect("~/user/Login");
            }
        }
    }
}