﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using STP.Models;

namespace STP.Account
{
    public partial class AddLetter : System.Web.UI.Page
    {
        private string fuid = "";
        private string tuid = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {
                if(Request.QueryString["id"] == null) Response.Redirect("~/index.aspx");
                tuid = Request.QueryString["id"].ToString().Trim();
                DB db = new DB();
                SqlDataReader dr = db.ExceRead("select id,nickname from users where name='" + Session["user"].ToString().Trim() + "'");
                if(dr.Read())
                {
                    Fname.Text = dr["nickname"].ToString().Trim();
                    this.fuid = dr["id"].ToString().Trim();
                    dr.Close();
                }
                dr = db.ExceRead("select nickname from users where id='" + tuid + "'");
                if(dr.Read())Tname.Text = dr["nickname"].ToString().Trim();
                dr.Close();
            }
            else
            {
                Session["returnUrl"] = Request.Url.ToString().Trim();
                Response.Redirect("~/user/Login");
            }
        }

        protected void submit_Click(object sender, EventArgs e)
        {
            string content = MyContent.Text;
            string title = MyTitle.Text;
            if (title.Length > 0)
            {
                DB db = new DB();
                db.ExceSql("exec insertLetter '" + this.fuid + "','" + this.tuid + "','" + title + "','" + content + "'");
                Response.Redirect("~/Account/ManageOutbox");
            }
            else
            {
                ErrorMessage.Visible = true;
                FailureText.Text = "请填写标题。";
            }
        }
    }
}