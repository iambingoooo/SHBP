﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using STP.Models;

namespace STP.Account
{
    public partial class ManageOutbox : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {
                Session["returnUrl"] = Request.Url;
                DB db = new DB();
                string sql = "select id from users where name='" + Session["user"] + "'";
                string id = "";
                SqlDataReader dr = db.ExceRead(sql);
                if (dr.Read())
                {
                    id = dr["id"].ToString().Trim();
                }
                dr.Close();
                sql = "select users.name,letters.tuid,letters.id,letters.ischecked,letters.ltitle,letters.lcontent,letters.time from users,letters where letters.fuid='" + id + "' and letters.buid='" + id + "' and letters.tuid=users.id ORDER BY letters.time DESC";
                dr = db.ExceRead(sql);
                TableRow trow = new TableRow();
                TableCell tcell1 = new TableCell();
                TableCell tcell2 = new TableCell();
                TableCell tcell3 = new TableCell();
                Label t1 = new Label();
                t1.Text = "主题";
                t1.Font.Bold = true;
                tcell1.Controls.Add(t1);
                Label t2 = new Label();
                t2.Text = "收信人";
                t2.Font.Bold = true;
                tcell2.Controls.Add(t2);
                Label t3 = new Label();
                t3.Text = "时间";
                t3.Font.Bold = true;
                tcell3.Controls.Add(t3);
                trow.Cells.Add(tcell1);
                trow.Cells.Add(tcell2);
                trow.Cells.Add(tcell3);
                Letters.Rows.Add(trow);
                while (dr.Read())
                {
                    TableRow row = new TableRow();
                    TableCell cell1 = new TableCell();
                    TableCell cell2 = new TableCell();
                    TableCell cell3 = new TableCell();
                    HyperLink title = new HyperLink();
                    title.Text = dr["ltitle"].ToString().Trim();
                    title.NavigateUrl = "~/Account/LetterInfo?id=" + dr["id"];
                    cell1.Controls.Add(title);
                    HyperLink tusername = new HyperLink();
                    tusername.Text = dr["name"].ToString().Trim();
                    tusername.NavigateUrl = "~/user/Userinfo?id=" + dr["tuid"];
                    cell2.Controls.Add(tusername);
                    Label time = new Label();
                    time.Text = dr["time"].ToString().Trim();
                    cell3.Controls.Add(time);
                    row.Cells.Add(cell1);
                    row.Cells.Add(cell2);
                    row.Cells.Add(cell3);
                    Letters.Rows.Add(row);
                }
            }
            else
            {
                Session["returnUrl"] = Request.Url.ToString();
                Response.Redirect("~/user/Login");
            }
        }
    }
}