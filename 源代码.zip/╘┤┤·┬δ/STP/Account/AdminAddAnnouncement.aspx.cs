﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using STP.Models;

namespace STP.Account
{
    public partial class AdminAddAnnouncement : System.Web.UI.Page
    {
        private string fuid = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null && Session["user"].ToString().Trim()=="siteAdmin")
            {
                DB db = new DB();
                SqlDataReader dr = db.ExceRead("select id from users where name='" + Session["user"].ToString().Trim() + "'");
                if(dr.Read())
                {
                    this.fuid = dr["id"].ToString().Trim();
                }
                dr.Close();
            }
            else
            {
                Response.Redirect("~/index.aspx");
            }
        }

        protected void submit_Click(object sender, EventArgs e)
        {
            string content = MyContent.Text;
            string title = MyTitle.Text;
            DB db = new DB();
            DB db2 = new DB();
            SqlDataReader dr;
            string tuid = "";
            if (title.Length > 0)
            {
                dr = db.ExceRead("select id from users where name<>'siteAdmin'");
                while(dr.Read())
                {
                    tuid = dr["id"].ToString().Trim();
                    db2.ExceSql("exec insertLetter '" + this.fuid + "','" + tuid + "','" + title + "','" + content + "'");
                }
                dr.Close();
                Response.Redirect("~/index.aspx");
            }
            else
            {
                ErrorMessage.Visible = true;
                FailureText.Text = "请填写标题。";
            }
        }
    }
}