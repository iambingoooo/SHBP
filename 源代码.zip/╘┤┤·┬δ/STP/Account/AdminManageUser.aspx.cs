﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using STP.Models;

namespace STP.Account
{
    public partial class AdminManageUser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null && Session["user"].ToString().Trim()=="siteAdmin")
            {
                DB db = new DB();
                DB db2 = new DB();
                //用户id
                string sql = "select id from users where name='" + Session["user"] + "'";
                string uid = "";
                SqlDataReader dr = db.ExceRead(sql);
                if (dr.Read())
                {
                    uid = dr["id"].ToString().Trim();
                }
                dr.Close();
                //获取用户们的id
                sql = "select name,id,photopath,disable from users where name<>'siteAdmin'";
                dr = db.ExceRead(sql);
                while (dr.Read())
                {
                    //根据用户id获取信息
                    string id = dr["id"].ToString().Trim();
                    string name = dr["name"].ToString().Trim();
                    string path = dr["photopath"].ToString().Trim();
                    string statestr = "正常使用";
                    if ((bool)dr["disable"] == true) statestr = "已封禁";
                    TableRow row = new TableRow();
                    TableCell cellHead = new TableCell();
                    TableCell cellContent = new TableCell();
                    TableCell cellState = new TableCell();
                    HyperLink img = new HyperLink();
                    if (path != null)
                        img.ImageUrl = path;
                    else
                        img.ImageUrl = "~/img/default.jpg";
                    img.ImageHeight = 200;
                    img.ImageWidth = 200;
                    HyperLink link = new HyperLink();
                    link.Text = name;
                    link.NavigateUrl = "~/user/UserInfo?id=" + id;
                    Label state = new Label();
                    state.Text = statestr;
                    cellHead.Controls.Add(img);
                    cellContent.Controls.Add(link);
                    cellState.Controls.Add(state);
                    row.Cells.Add(cellHead);
                    row.Cells.Add(cellContent);
                    row.Cells.Add(cellState);
                    Users.Rows.Add(row);
                }
                dr.Close();
            }
            else
            {
                Response.Redirect("~/index.aspx");
            }
        }
    }
}