﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(STP.Startup))]
namespace STP
{
    public partial class Startup {
        public void Configuration(IAppBuilder app)
        {
        }
    }
}
