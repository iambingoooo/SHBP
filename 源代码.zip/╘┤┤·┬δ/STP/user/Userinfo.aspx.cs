﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using STP.Models;

namespace STP.Product
{
    public partial class Userinfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DB db = new DB();
            SqlDataReader dr;
            if (Request.QueryString["id"] != null)
            {
                //获取用户信息
                string sql = "select * from users where id='" + Request.QueryString["id"].ToString().Trim() + "'";
                dr = db.ExceRead(sql);
                if (dr.Read())
                {
                    if ((bool)dr["disable"]==false)
                    { 
                        disable.Text = "正常"; 
                    }
                    else
                    {
                        disable.Text = "禁用";
                    } 
                    avatar.Height = 200;
                    avatar.Width = 200;
                    if (dr["photopath"] != null && dr["photopath"].ToString().Length>1)
                    {
                        avatar.ImageUrl = dr["photopath"].ToString().Trim();
                    }
                    if (dr["nickname"] != null) nickname.Text = dr["nickname"].ToString().Trim();
                    if (dr["sex"] != null)
                    {
                        if (dr["sex"].ToString() == "m") sex.Text = "男";
                        else sex.Text = "女";
                    }
                    if (dr["sno"] != null) sno.Text = dr["sno"].ToString().Trim();
                    if (dr["major"] != null) major.Text = dr["major"].ToString().Trim();
                    if (dr["entryyear"] != null) entryyear.Text = dr["entryyear"].ToString().Trim();
                    if (dr["QQ"] != null) qq.Text = dr["QQ"].ToString().Trim();
                    if (dr["tel"] != null) tel.Text = dr["tel"].ToString().Trim();
                    if (dr["email"] != null) email.Text = dr["email"].ToString().Trim();
                    if (dr["rating"] != null) rating.Text = dr["rating"].ToString().Trim();
                }
                dr.Close();
                //设置好友相关
                addFriend.Visible = false;
                deleteFriend.Visible = false;
                //设置封禁相关
                setDisable.Visible = false;
                removeDisable.Visible = false;
                changeRating.Visible = true;
                changeRating.Visible = false;
                label233.Visible = false;
                ratingBox.Visible = false;
                if(Session["user"]!=null)
                {
                    string buid = "";
                    string tuid = Request.QueryString["id"].ToString().Trim();
                    if (Session["user"].ToString().Trim() == "siteAdmin")
                    {
                        changeRating.Visible = true;
                        label233.Visible = true;
                        ratingBox.Visible = true;
                        dr = db.ExceRead("select disable from users where id='" + tuid + "'");
                        if (dr.Read())
                        {
                            if ((bool)dr["disable"] == false) setDisable.Visible = true;
                            else removeDisable.Visible = true;
                        }
                        dr.Close();
                    }
                    else
                    {
                        //本人用户id
                        dr = db.ExceRead("select id from users where name='" + Session["user"].ToString().Trim() + "'");
                        if (dr.Read()) buid = dr["id"].ToString().Trim();
                        dr.Close();
                        //如果是本人，则不显示好友相关,也不显示发私信
                        if (buid == tuid)
                        {
                            submit.Visible = false;
                            return;
                        }
                        //获取好友信息
                        dr = db.ExceRead("select * from friends where buid='" + buid + "' and tuid='" + tuid + "'");
                        if (dr.Read())
                        {
                            deleteFriend.Visible = true;
                        }
                        else
                        {
                            addFriend.Visible = true;
                        }
                        dr.Close();
                    }
                }

            }
            else
            {
                Response.Redirect("~/index");
            }
        }

        protected void submit_Click(object sender, EventArgs e)
        {
            if(Session["user"]!=null)
            {
                Response.Redirect("~/Account/AddLetter?id=" + Request.QueryString["id"].ToString().Trim());
            }
            else
            {
                Session["returnUrl"] = Request.Url.ToString().Trim();
                Response.Redirect("~/user/Login");
            }
        }

        protected void addFriend_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            string buid="";
            string tuid = Request.QueryString["id"];
            SqlDataReader dr = db.ExceRead("select id from users where name='" + Session["user"].ToString().Trim() + "'");
            if (dr.Read()) buid = dr["id"].ToString().Trim();
            dr.Close();
            db.ExceSql("exec insertFriend '" + buid + "','" + tuid + "'");
            Response.Redirect(Request.Url.ToString());
        }

        protected void deleteFriend_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            string buid="";
            string tuid = Request.QueryString["id"];
            SqlDataReader dr = db.ExceRead("select id from users where name='" + Session["user"].ToString().Trim() + "'");
            if (dr.Read()) buid = dr["id"].ToString().Trim();
            dr.Close();
            db.ExceSql("delete from friends where buid='" + buid + "' and tuid='" + tuid + "'");
            Response.Redirect(Request.Url.ToString());
        }

        protected void setDisable_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            string tuid = Request.QueryString["id"];
            db.ExceSql("update users set disable=1 where id='" + tuid + "'");
            Response.Redirect(Request.Url.ToString());
        }

        protected void removeDisable_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            string tuid = Request.QueryString["id"];
            db.ExceSql("update users set disable=0 where id='" + tuid + "'");
            Response.Redirect(Request.Url.ToString());
        }

        protected void changeRating_Click1(object sender, EventArgs e)
        {
            DB db = new DB();
            string tuid = Request.QueryString["id"];
            db.ExceSql("update users set rating="+ratingBox.Text+" where id='" + tuid + "'");
            Response.Redirect(Request.Url.ToString());
        }
    }
}