﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using STP.Models;

namespace STP.Account
{
    public partial class Userinfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {
                DB db = new DB();
                string sql = "select * from users where name='" + Session["user"].ToString() + "'";
                SqlDataReader dr = db.ExceRead(sql);
                if (dr.Read())
                {
                    name.Text = dr["name"].ToString().Trim();
                    birthdate.Text = dr["birthdate"].ToString().Trim();
                    if ((bool)dr["disable"]==false)
                    { 
                        disable.Text = "正常"; 
                    }
                    else
                    {
                        disable.Text = "禁用";
                    } 
                    avatar.Height = 200;
                    avatar.Width = 200;
                    if (dr["photopath"] != null && dr["photopath"].ToString().Length>1)
                    {
                        avatar.ImageUrl = dr["photopath"].ToString().Trim();
                    }
                    if (dr["nickname"] != null) nickname.Text = dr["nickname"].ToString().Trim();
                    if (dr["sex"] != null)
                    {
                        if (dr["sex"].ToString() == "m") sex.Text = "男";
                        else sex.Text = "女";
                    }
                    if (dr["sno"] != null) sno.Text = dr["sno"].ToString().Trim();
                    if (dr["major"] != null) major.Text = dr["major"].ToString().Trim();
                    if (dr["entryyear"] != null) entryyear.Text = dr["entryyear"].ToString().Trim();
                    if (dr["QQ"] != null) qq.Text = dr["QQ"].ToString().Trim();
                    if (dr["tel"] != null) tel.Text = dr["tel"].ToString().Trim();
                    if (dr["email"] != null) email.Text = dr["email"].ToString().Trim();
                }
            }
            else
            {
                Session["returnUrl"] = Request.Url.ToString();
                Response.Redirect("~/user/Login");
            }
        }

        protected void submit_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/user/edit.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/user/editpassword");
        }
    }
}