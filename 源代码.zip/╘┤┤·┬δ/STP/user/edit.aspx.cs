﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using STP.Models;
using System.IO;

namespace STP.Account
{
    public partial class ChangeUserinfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {
                DB db = new DB();
                string sql = "select * from users where name='" + Session["user"].ToString() + "'";
                SqlDataReader dr = db.ExceRead(sql);
                if (dr.Read())
                {
                    if (!IsPostBack)
                    {
                          if (dr["nickname"] != null) nickname.Text = dr["nickname"].ToString().Trim();
                        if (dr["sex"] != null)
                        {
                            if (dr["sex"].ToString() == "m") sexlist.SelectedValue="1";
                            else sexlist.SelectedValue="2";
                        }
                        if (dr["birthdate"] != null) birthdate.Text = dr["birthdate"].ToString().Trim();
                        if (dr["sno"] != null) sno.Text = dr["sno"].ToString().Trim();
                        if (dr["major"] != null) major.Text = dr["major"].ToString().Trim();
                        if (dr["entryyear"] != null) entryyear.Text = dr["entryyear"].ToString().Trim();
                        if (dr["QQ"] != null) qq.Text = dr["QQ"].ToString().Trim();
                        if (dr["tel"] != null) tel.Text = dr["tel"].ToString().Trim();
                        if (dr["email"] != null) email.Text = dr["email"].ToString().Trim();
                    }
                }
                dr.Close();
            }
            else
            {
                Response.Redirect("~/index.aspx");
            }
        }

        protected void submit_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            Boolean fileOk = false;
            string Nickname=nickname.Text;
            string Sex;
            if(Int32.Parse(sexlist.SelectedValue)==1)Sex="m";
            else Sex="f";
            string Email= email.Text;
            string Sno=sno.Text;
            string Major=major.Text;
            string QQ=qq.Text;
            string Tel=tel.Text;
            string Entryyear=entryyear.Text;
            string Birthdate=birthdate.Text;
            string sql = "update users set nickname='" + Nickname + "' where name='" + Session["user"].ToString().Trim() +"'";
            db.ExceSql(sql);
            sql = "update users set sex='" + Sex + "' where name='" + Session["user"].ToString().Trim() + "'";
            db.ExceSql(sql);
            sql = "update users set email='" + Email + "' where name='" + Session["user"].ToString().Trim() + "'";
            db.ExceSql(sql);
            sql = "update users set major='" + Major + "' where name='" + Session["user"].ToString().Trim() + "'";
            db.ExceSql(sql);
            sql = "update users set qq='" + QQ + "' where name='" + Session["user"].ToString().Trim() + "'";
            db.ExceSql(sql);
            sql = "update users set tel='" + Tel + "' where name='" + Session["user"].ToString().Trim() + "'";
            db.ExceSql(sql);
            sql = "update users set entryyear='" + Entryyear + "' where name='" + Session["user"].ToString().Trim() + "'";
            db.ExceSql(sql);
            sql = "update users set birthdate='" + Birthdate + "' where name='" + Session["user"].ToString().Trim() + "'";
            db.ExceSql(sql);
            sql = "update users set sno='" + Sno + "' where name='" + Session["user"].ToString().Trim() + "'";
            db.ExceSql(sql);
            
            if (picUpload.HasFile)//验证是否包含文件
            {
                string mappath = "";
                string virpath = "";
                //取得文件的扩展名,并转换成小写
                string fileExtension = Path.GetExtension(picUpload.FileName).ToLower();
                //验证上传文件是否图片格式
                fileOk = IsImage(fileExtension);
                if (fileOk)
                {
                    //对上传文件的大小进行检测，限定文件最大不超过8M
                    if (picUpload.PostedFile.ContentLength < 8192000)
                    {
                        string filepath = "/img/";
                        if (Directory.Exists(Server.MapPath(filepath)) == false)//如果不存在就创建file文件夹
                        {
                            Directory.CreateDirectory(Server.MapPath(filepath));
                        }
                        virpath = filepath + "useravatar_" + Session["user"].ToString().Trim() + fileExtension;//这是存到服务器上的虚拟路径
                        mappath = Server.MapPath(virpath);//转换成服务器上的物理路径
                        picUpload.PostedFile.SaveAs(mappath);//保存图片
                        //清空提示
                        picLabel.Text = "";
                        sql = "update users set photopath='" + virpath + "' where name='" + Session["user"].ToString().Trim() + "'";
                        db.ExceSql(sql);
                    }
                    else
                    {
                        picLabel.Text = "文件大小超出8M！请重新选择！";
                    }
                }
                else
                {
                    picLabel.Text = "要上传的文件类型不对！请重新选择！";
                }
            }
            Response.Redirect("~/user/detail");
        }
        public bool IsImage(string str)
        {
            bool isimage = false;
            string thestr = str.ToLower();
            //限定只能上传jpg和gif图片
            string[] allowExtension = { ".jpg", ".gif", ".bmp", ".png" };
            //对上传的文件的类型进行一个个匹对
            for (int i = 0; i < allowExtension.Length; i++)
            {
                if (thestr == allowExtension[i])
                {
                    isimage = true;
                    break;
                }
            }
            return isimage;
        }

        protected void cancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/index.aspx");
        }
    }
}