﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using STP.Models;
using System.Data.SqlClient;
using System.Data;

namespace STP
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            searchBook.NavigateUrl = "~/SearchResult?tag=图书&type=0";
            searchElec.NavigateUrl = "~/SearchResult?tag=电子产品&type=0";
            searchHot.NavigateUrl = "~/SearchResult?type=0";
            if (!IsPostBack)
            {
                Tag.SelectedIndex = 0;
                Type.SelectedIndex = 0;
            }
            DB db = new DB();
            //热门
            SqlDataReader dr = db.ExceRead("exec selectProduct ''");
            if(dr.Read())
            {
                hotk1.NavigateUrl=hotkk1.NavigateUrl=hot1.NavigateUrl = "~/merchandise/detail?id=" + dr["id"].ToString().Trim();
                hotm1.ImageUrl = dr["path"].ToString().Trim();
                hotll1.Text=hotl1.Text = dr["name"].ToString().Trim();

            }
            if (dr.Read())
            {
                hotk2.NavigateUrl = hotkk2.NavigateUrl = hot2.NavigateUrl = "~/merchandise/detail?id=" + dr["id"].ToString().Trim();
                hotm2.ImageUrl = dr["path"].ToString().Trim();
                hotll2.Text = hotl2.Text = dr["name"].ToString().Trim();
            }
            if (dr.Read())
            {
                hotk3.NavigateUrl = hotkk3.NavigateUrl = hot3.NavigateUrl = "~/merchandise/detail?id=" + dr["id"].ToString().Trim();
                hotm3.ImageUrl = dr["path"].ToString().Trim();
                hotll3.Text = hotl3.Text = dr["name"].ToString().Trim();
            }
            if (dr.Read())
            {
                hotk4.NavigateUrl = hotkk4.NavigateUrl = hot4.NavigateUrl = "~/merchandise/detail?id=" + dr["id"].ToString().Trim();
                hotm4.ImageUrl = dr["path"].ToString().Trim();
                hotll4.Text = hotl4.Text = dr["name"].ToString().Trim();
            }
            if (dr.Read())
            {
                hotk5.NavigateUrl = hotkk5.NavigateUrl = hot5.NavigateUrl = "~/merchandise/detail?id=" + dr["id"].ToString().Trim();
                hotm5.ImageUrl = dr["path"].ToString().Trim();
                hotll5.Text = hotl5.Text = dr["name"].ToString().Trim();
            }
            if (dr.Read())
            {
                hotk6.NavigateUrl = hotkk6.NavigateUrl = hot6.NavigateUrl = "~/merchandise/detail?id=" + dr["id"].ToString().Trim();
                hotm6.ImageUrl = dr["path"].ToString().Trim();
                hotll6.Text=hotl6.Text = dr["name"].ToString().Trim();
            }

            dr.Close();
            //图书
            dr = db.ExceRead("exec selectProduct '书'");
            if (dr.Read())
            {
                bookk1.NavigateUrl = bookkk1.NavigateUrl = book1.NavigateUrl = "~/merchandise/detail?id=" + dr["id"].ToString().Trim();
                bookm1.ImageUrl = dr["path"].ToString().Trim();
                bookll1.Text = bookl1.Text = dr["name"].ToString().Trim();
            }
            if (dr.Read())
            {
                bookk2.NavigateUrl = bookkk2.NavigateUrl = book2.NavigateUrl = "~/merchandise/detail?id=" + dr["id"].ToString().Trim();
                bookm2.ImageUrl = dr["path"].ToString().Trim();
                bookll2.Text = bookl2.Text = dr["name"].ToString().Trim();
            }
            if (dr.Read())
            {
                bookk3.NavigateUrl = bookkk3.NavigateUrl = book3.NavigateUrl = "~/merchandise/detail?id=" + dr["id"].ToString().Trim();
                bookm3.ImageUrl = dr["path"].ToString().Trim();
                bookll3.Text = bookl3.Text = dr["name"].ToString().Trim();
            }
            dr.Close();
            //电子产品
            dr = db.ExceRead("exec selectProduct '电'");
            if (dr.Read())
            {
                eleck1.NavigateUrl = eleckk1.NavigateUrl = elec1.NavigateUrl = "~/merchandise/detail?id=" + dr["id"].ToString().Trim();
                elecm1.ImageUrl = dr["path"].ToString().Trim();
                elecll1.Text = elecl1.Text = dr["name"].ToString().Trim();
            }
            if (dr.Read())
            {
                eleck2.NavigateUrl = eleckk2.NavigateUrl = elec2.NavigateUrl = "~/merchandise/detail?id=" + dr["id"].ToString().Trim();
                elecm2.ImageUrl = dr["path"].ToString().Trim();
                elecll2.Text = elecl2.Text = dr["name"].ToString().Trim();
            }
            if (dr.Read())
            {
                eleck3.NavigateUrl = eleckk3.NavigateUrl = elec3.NavigateUrl = "~/merchandise/detail?id=" + dr["id"].ToString().Trim();
                elecm3.ImageUrl = dr["path"].ToString().Trim();
                elecll3.Text = elecl3.Text = dr["name"].ToString().Trim();
            }
            dr.Close();
        }

        protected void Unnamed1_Click(object sender, EventArgs e)
        {
            string keyword = Keyword.Text;
            string tags = Tag.SelectedValue;
            string type = Type.SelectedIndex.ToString();
            Response.Redirect("~/SearchResult?key=" + keyword + "&tag=" + tags + "&type=" + type);
        }
    }
}