﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using STP.Models;
using System.Collections;

namespace STP.Product
{
    public partial class SearchResult : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string searchkey = "";
            string searchtag = "";
            string[] taglist={};
            string searchtype = "0";
            if (!string.IsNullOrWhiteSpace(Request.QueryString["key"]) && Request.QueryString["key"].ToString().Trim().Length > 0)
            {
                searchkey = Request.QueryString["key"].ToString().Trim();
            }
            if (!string.IsNullOrWhiteSpace(Request.QueryString["tag"]) && Request.QueryString["tag"].ToString().Trim().Length > 0)
            {
                searchtag = Request.QueryString["tag"].ToString().Trim();
                taglist = searchtag.Split(',');
            }
            if (!string.IsNullOrWhiteSpace(Request.QueryString["type"]) && Request.QueryString["type"].ToString().Trim().Length > 0)
            {
                searchtype = Request.QueryString["type"].ToString().Trim();
            }
            //设置单选框的值
            if (!IsPostBack)
            {
                if (searchtag.Trim() == "图书") Tag.SelectedIndex = 1;
                else if (searchtag.Trim() == "电子产品") Tag.SelectedIndex = 2;
                else Tag.SelectedIndex = 0;
                if (searchtype == "1") Type.SelectedIndex = 1;
                else Type.SelectedIndex = 0;
            }
            //分情况搜索，商品或者需求
            DB db = new DB();
            DB db2 = new DB();
            SqlDataReader dr;
            if (searchtype == "0")
            {
                dr = db.ExceRead("exec selectProduct '" + searchkey + "'");
                while(dr.Read())
                {
                    //检测是否符合tag
                    SqlDataReader dr2 = db2.ExceRead("exec selectTagsByProductId '" + dr["id"].ToString().Trim() + "'");
                    bool ok = false;
                    if (taglist.Length < 1) ok = true;
                    while(dr2.Read())
                    {
                        string ptag = dr2["name"].ToString().Trim();
                        foreach(string tag in taglist)
                        {
                            if(tag.Length>0)
                            {
                                if (ptag.IndexOf(tag) >= 0)
                                {
                                    ok = true;
                                    break;
                                }
                            }
                        }
                        if (ok) break;
                    }
                    dr2.Close();
                    if (!ok) continue;
                    TableRow row = new TableRow();
                    TableCell cellHead = new TableCell();
                    TableCell cellContent = new TableCell();
                    Image img = new Image();
                    img.ImageUrl = dr["path"].ToString().Trim();
                    img.Width = 200;
                    img.Height = 200;
                    HyperLink link = new HyperLink();
                    link.Text = dr["name"].ToString().Trim();
                    link.NavigateUrl = "~/merchandise/detail?id=" + dr["id"];
                    cellHead.Controls.Add(img);
                    cellContent.Controls.Add(link);
                    row.Cells.Add(cellHead);
                    row.Cells.Add(cellContent);
                    products.Rows.Add(row);
                }
                dr.Close();
            }
            else
            {
                dr = db.ExceRead("exec selectRequire '" + searchkey + "'");
                while (dr.Read())
                {
                    //检测是否符合tag
                    SqlDataReader dr2 = db2.ExceRead("exec selectTagsByRequireId '" + dr["id"].ToString().Trim() + "'");
                    bool ok = false;
                    if (taglist.Length < 1) ok = true;
                    while (dr2.Read())
                    {
                        string rtag = dr2["name"].ToString().Trim();
                        foreach (string tag in taglist)
                        {
                            if (tag.Length > 0)
                            {
                                if (rtag.IndexOf(tag) >= 0)
                                {
                                    ok = true;
                                    break;
                                }
                            }
                        }
                        if (ok) break;
                    }
                    dr2.Close();
                    if (!ok) continue;
                    TableRow row = new TableRow();
                    TableCell cellHead = new TableCell();
                    TableCell cellContent = new TableCell();
                    Image img = new Image();
                    img.ImageUrl = dr["path"].ToString().Trim();
                    img.Width = 200;
                    img.Height = 200;
                    HyperLink link = new HyperLink();
                    link.Text = dr["name"].ToString().Trim();
                    link.NavigateUrl = "~/demand/detail?id=" + dr["id"];
                    cellHead.Controls.Add(img);
                    cellContent.Controls.Add(link);
                    row.Cells.Add(cellHead);
                    row.Cells.Add(cellContent);
                    products.Rows.Add(row);
                }
                dr.Close();
            }
            
            
        }

        protected void Unnamed1_Click(object sender, EventArgs e)
        {
            string key = searchBox.Text.Trim();
            string tag = Tag.SelectedValue.ToString().Trim();
            string type = Type.SelectedValue.ToString().Trim();
            if (string.IsNullOrWhiteSpace(type)) type = "0";
            Response.Redirect("~/SearchResult?key=" + key + "&tag=" + tag + "&type=" + type);
        }
    }
}