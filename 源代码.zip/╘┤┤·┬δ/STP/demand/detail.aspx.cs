﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using STP.Models;

namespace STP.Product
{
    public partial class RequireInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["id"] == null || Request.QueryString["id"].Length < 1)
            {
                Response.Redirect("~/index.aspx");
                return;
            }
            DB db = new DB();
            //需求id
            string rid = Request.QueryString["id"].ToString().Trim();
            //隐藏删除按钮
            deleteRequire.Visible = false;
            contact.Visible = true;
            edit.Visible = false;
            //获取和展示需求信息
            string sql = "exec selectRequireById '" + rid + "'";
            SqlDataReader dr = db.ExceRead(sql);
            if (dr.Read())
            {
                string userid = dr["uid"].ToString().Trim();
                Name.Text = dr["name"].ToString().Trim();
                Image.ImageUrl = dr["path"].ToString().Trim();
                Content.Text = dr["content"].ToString().Trim();
                Time.Text = dr["time"].ToString().Trim();
                dr.Close();
                string tags = "";
                dr = db.ExceRead("exec selectTagsByRequireId '" + rid + "'");
                if (dr.Read())
                {
                    tags += dr["name"] + ",";
                }
                if (tags.Length > 0) tags = tags.Substring(0, tags.Length - 1);
                Tags.Text = tags;
                dr.Close();
                dr = db.ExceRead("select nickname from users where id='" + userid + "'");
                if (dr.Read())
                {
                    Username.Text = dr["nickname"].ToString().Trim();
                    Username.NavigateUrl = "~/user/Userinfo?id=" + userid;
                }
                dr.Close();
                string uid = "";
                dr = db.ExceRead("select id from users where name='" + Session["user"].ToString().Trim() + "'");
                if (dr.Read()) uid = dr["id"].ToString().Trim();
                dr.Close();
                //如果是管理员，显示可以一键删除需求的权限按钮
                if (Session["user"] != null && Session["user"].ToString().Trim() == "siteAdmin")
                {
                    deleteRequire.Visible = true;
                }
                else if(userid==uid)
                {
                    deleteRequire.Visible = true;
                    contact.Visible = false;
                    edit.Visible = true;
                }
            }
            else
            {
                Response.Redirect("~/index.aspx");
                return;
            }
        }

        protected void deleteProduct_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            //需求id
            string rid = Request.QueryString["id"].ToString().Trim();
            //删除需求
            db.ExceSql("delete from requires where id='" + rid + "'");
            db.ExceSql("delete from requires_tags where rid='" + rid + "'");
            db.ExceSql("delete from requires_images where rid='" + rid + "'");
            Response.Redirect("~/demand/index");
        }

        protected void contact_Click(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {
                Response.Redirect("~/Account/AddLetter?id=" + Request.QueryString["id"].ToString().Trim());
            }
            else
            {
                Session["returnUrl"] = Request.Url.ToString().Trim();
                Response.Redirect("~/user/Login");
            }
        }

        protected void edit_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/demand/edit?id=" + Request.QueryString["id"]);
        }
    }
}